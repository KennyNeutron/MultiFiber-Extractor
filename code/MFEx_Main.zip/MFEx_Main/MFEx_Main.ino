/**
 * MultiFiber-Extractor Main Program
 * Description: Basic demonstration for a 20x4 I2C LCD displaying "Hello World".
 * Author: 
 * Date Started: Mar 5, 2026
 */

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include "variables.h"

#define RollerMotorPin 10
#define ReedSwitch1_Pin 8
#define ExtractorMotorPin 12


// I2C address 0x27, 20 columns, 4 rows
LiquidCrystal_I2C lcd(0x27, 20, 4);

struct FiberData {
  const char* name;
  int speed;
  int gap;
};

const FiberData fibers[] = {
  { "Banana       ", 750, 2 },
  { "Abaca        ", 715, 3 },
  { "Pineapple    ", 150, 3 },
  { "Snake Plant  ", 150, 5 }
};

bool testVar = false;
volatile bool ReedSwitch1_Status = false;

void setup() {
  Serial.begin(9600);
  Serial.println("MultiFiber-Extractor \nSystem Booting...");

  buttons_Setup();

  pinMode(RollerMotorPin, OUTPUT);
  pinMode(ReedSwitch1_Pin, INPUT_PULLUP);
  digitalWrite(RollerMotorPin, LOW);

  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("SYSTEM BOOTING...");
  delay(3000);
  CurrentScreen = 0x1000;

  ISR_Setup();

  lcd.setCursor(0, 1);
  lcd.print("CALIBRATING...");

  Actuator_Setup();
  delay(1000);
  Actuator_Reset();

  // //4mm gap
  // Actuator_Right_Down();
  // Actuator_Left_Down();
  // delay(1200);
  // Actuator_OffAll();

  pinMode(RollerMotorPin, OUTPUT);
  analogWrite(RollerMotorPin, 0);

  pinMode(ExtractorMotorPin, OUTPUT);
  digitalWrite(ExtractorMotorPin, 0);
  delay(2000);
  // digitalWrite(ExtractorMotorPin, 1);
  // delay(2000);
  // digitalWrite(ExtractorMotorPin, 0);
}

void loop() {

  if (Status_btn_Prev()) {
    Serial.println("Previous Button Pressed");
  }
  if (Status_btn_Next()) {
    Serial.println("Next Button Pressed");
  }
  if (Status_btn_Select()) {
    Serial.println("Select Button Pressed");
  }

  Display_Loop();
}